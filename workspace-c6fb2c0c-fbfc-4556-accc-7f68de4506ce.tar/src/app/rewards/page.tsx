"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  Gift, 
  ArrowLeft, 
  Search, 
  Filter,
  Star,
  ShoppingCart,
  CheckCircle,
  AlertCircle,
  Clock,
  Package
} from "lucide-react"

interface Reward {
  id: string
  name: string
  description: string
  image?: string
  points: number
  category: string
  stock: number
  isActive: boolean
}

interface UserReward {
  id: string
  rewardId: string
  pointsUsed: number
  status: string
  redeemedAt: string
  fulfilledAt?: string
  reward: Reward
}

export default function RewardsPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [rewards, setRewards] = useState<Reward[]>([])
  const [userRewards, setUserRewards] = useState<UserReward[]>([])
  const [userPoints, setUserPoints] = useState(0)
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [redeemingReward, setRedeemingReward] = useState<Reward | null>(null)
  const [isRedeeming, setIsRedeeming] = useState(false)
  const [redeemMessage, setRedeemMessage] = useState<{ type: 'success' | 'error', message: string } | null>(null)

  const categories = ["all", "Electronics", "Vouchers", "Eco-friendly", "Home & Garden", "Sports & Outdoors"]

  useEffect(() => {
    if (!session) {
      router.push("/auth/signin")
      return
    }

    const fetchData = async () => {
      try {
        // Fetch user data
        const userResponse = await fetch("/api/user/profile")
        if (userResponse.ok) {
          const userData = await userResponse.json()
          setUserPoints(userData.points)
        }

        // Fetch rewards
        const rewardsResponse = await fetch("/api/rewards")
        if (rewardsResponse.ok) {
          const rewardsData = await rewardsResponse.json()
          setRewards(rewardsData)
        }

        // Fetch user rewards
        const userRewardsResponse = await fetch("/api/user/rewards")
        if (userRewardsResponse.ok) {
          const userRewardsData = await userRewardsResponse.json()
          setUserRewards(userRewardsData)
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [session, router])

  const filteredRewards = rewards.filter(reward => {
    const matchesSearch = reward.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reward.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || reward.category === selectedCategory
    return matchesSearch && matchesCategory && reward.isActive
  })

  const handleRedeem = async (reward: Reward) => {
    if (userPoints < reward.points) {
      setRedeemMessage({ type: 'error', message: 'Insufficient points' })
      return
    }

    setRedeemingReward(reward)
    setIsRedeeming(true)
    setRedeemMessage(null)

    try {
      const response = await fetch("/api/user/rewards", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          rewardId: reward.id,
          pointsUsed: reward.points,
        }),
      })

      if (response.ok) {
        setRedeemMessage({ type: 'success', message: 'Reward redeemed successfully!' })
        // Refresh data
        const userResponse = await fetch("/api/user/profile")
        if (userResponse.ok) {
          const userData = await userResponse.json()
          setUserPoints(userData.points)
        }
        const userRewardsResponse = await fetch("/api/user/rewards")
        if (userRewardsResponse.ok) {
          const userRewardsData = await userRewardsResponse.json()
          setUserRewards(userRewardsData)
        }
      } else {
        const errorData = await response.json()
        setRedeemMessage({ type: 'error', message: errorData.error || 'Failed to redeem reward' })
      }
    } catch (error) {
      console.error("Error redeeming reward:", error)
      setRedeemMessage({ type: 'error', message: 'An error occurred while redeeming the reward' })
    } finally {
      setIsRedeeming(false)
      setRedeemingReward(null)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>
      case 'fulfilled':
        return <Badge variant="default"><CheckCircle className="h-3 w-3 mr-1" />Fulfilled</Badge>
      case 'cancelled':
        return <Badge variant="destructive"><AlertCircle className="h-3 w-3 mr-1" />Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                onClick={() => router.back()}
                className="mr-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">Rewards Catalog</h1>
            </div>
            <div className="flex items-center space-x-2">
              <div className="text-sm font-medium text-gray-700">
                Your Points:
              </div>
              <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full font-semibold">
                {userPoints}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search rewards..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category === "all" ? "All Categories" : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* My Rewards Section */}
        {userRewards.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">My Rewards</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userRewards.map((userReward) => (
                <Card key={userReward.id} className="border-l-4 border-l-green-500">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{userReward.reward.name}</CardTitle>
                      {getStatusBadge(userReward.status)}
                    </div>
                    <CardDescription>
                      Redeemed on {new Date(userReward.redeemedAt).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{userReward.reward.description}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Points used:</span>
                      <span className="font-medium">{userReward.pointsUsed}</span>
                    </div>
                    {userReward.fulfilledAt && (
                      <div className="flex items-center justify-between text-sm mt-2">
                        <span className="text-gray-500">Fulfilled:</span>
                        <span className="font-medium">{new Date(userReward.fulfilledAt).toLocaleDateString()}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Available Rewards */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Rewards</h2>
          
          {filteredRewards.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Gift className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No rewards found</h3>
                <p className="text-gray-600">
                  Try adjusting your search or filter criteria.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRewards.map((reward) => {
                const canAfford = userPoints >= reward.points
                const isInStock = reward.stock > 0
                
                return (
                  <Card key={reward.id} className={`transition-all hover:shadow-lg ${!canAfford || !isInStock ? 'opacity-75' : ''}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{reward.name}</CardTitle>
                          <CardDescription className="mt-1">
                            {reward.description}
                          </CardDescription>
                        </div>
                        <div className="ml-2">
                          <Badge variant="outline">{reward.category}</Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span className="font-semibold text-lg">{reward.points}</span>
                            <span className="text-sm text-gray-600">points</span>
                          </div>
                          <div className="flex items-center space-x-1 text-sm text-gray-600">
                            <Package className="h-4 w-4" />
                            <span>{reward.stock} in stock</span>
                          </div>
                        </div>
                        
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              className="w-full"
                              disabled={!canAfford || !isInStock}
                              variant={canAfford && isInStock ? "default" : "secondary"}
                            >
                              <ShoppingCart className="h-4 w-4 mr-2" />
                              {!canAfford ? 'Insufficient Points' : !isInStock ? 'Out of Stock' : 'Redeem Reward'}
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Confirm Redemption</DialogTitle>
                              <DialogDescription>
                                Are you sure you want to redeem "{reward.name}" for {reward.points} points?
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="bg-gray-50 p-4 rounded-lg">
                                <h4 className="font-semibold mb-2">Reward Details</h4>
                                <p className="text-sm text-gray-600 mb-2">{reward.description}</p>
                                <div className="flex justify-between text-sm">
                                  <span>Points required:</span>
                                  <span className="font-semibold">{reward.points}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                  <span>Your current points:</span>
                                  <span className="font-semibold">{userPoints}</span>
                                </div>
                                <div className="flex justify-between text-sm mt-2">
                                  <span>Points after redemption:</span>
                                  <span className="font-semibold">{userPoints - reward.points}</span>
                                </div>
                              </div>
                              
                              {redeemMessage && (
                                <Alert variant={redeemMessage.type === 'error' ? 'destructive' : 'default'}>
                                  <AlertDescription>{redeemMessage.message}</AlertDescription>
                                </Alert>
                              )}
                              
                              <div className="flex space-x-2">
                                <Button 
                                  onClick={() => handleRedeem(reward)}
                                  disabled={isRedeeming}
                                  className="flex-1"
                                >
                                  {isRedeeming ? (
                                    <>
                                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                      Redeeming...
                                    </>
                                  ) : (
                                    'Confirm Redemption'
                                  )}
                                </Button>
                                <Button variant="outline" onClick={() => setRedeemMessage(null)}>
                                  Cancel
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </section>
      </main>
    </div>
  )
}