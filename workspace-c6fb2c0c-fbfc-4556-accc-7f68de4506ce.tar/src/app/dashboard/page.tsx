"use client"

import { useSession, signOut } from "next-auth/react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Bottle, 
  Leaf, 
  Gift, 
  TrendingUp, 
  LogOut,
  User,
  Award,
  Plus,
  History,
  Target,
  Calendar,
  MapPin,
  Trophy
} from "lucide-react"

interface UserData {
  points: number
  level: number
  totalBottles: number
  totalWeight: number
  co2Saved: number
}

interface Deposit {
  id: string
  bottleType: string
  quantity: number
  weight: number
  points: number
  location?: string
  verified: boolean
  createdAt: string
}

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [userData, setUserData] = useState<UserData | null>(null)
  const [deposits, setDeposits] = useState<Deposit[]>([])
  const [loadingDeposits, setLoadingDeposits] = useState(true)

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/")
    }
  }, [status, router])

  useEffect(() => {
    if (session) {
      // Fetch user data
      const fetchUserData = async () => {
        try {
          const response = await fetch("/api/user/profile")
          if (response.ok) {
            const data = await response.json()
            setUserData(data)
          }
        } catch (error) {
          console.error("Error fetching user data:", error)
        }
      }

      // Fetch deposits
      const fetchDeposits = async () => {
        try {
          const response = await fetch("/api/deposits")
          if (response.ok) {
            const data = await response.json()
            setDeposits(data)
          }
        } catch (error) {
          console.error("Error fetching deposits:", error)
        } finally {
          setLoadingDeposits(false)
        }
      }

      fetchUserData()
      fetchDeposits()
    }
  }, [session])

  if (status === "loading" || !userData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!session) {
    return null
  }

  const getLevelProgress = (level: number) => {
    const levelThresholds = [0, 100, 300, 600, 1000, 1500, 2100, 2800, 3600, 4500]
    const currentLevelMin = levelThresholds[level - 1] || 0
    const nextLevelMin = levelThresholds[level] || currentLevelMin + 1000
    const progress = ((userData.points - currentLevelMin) / (nextLevelMin - currentLevelMin)) * 100
    return Math.min(progress, 100)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-green-600 mr-2" />
              <h1 className="text-2xl font-bold text-gray-900">EcoBottle</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.push("/impact")}
              >
                <Leaf className="h-4 w-4 mr-2" />
                My Impact
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.push("/leaderboard")}
              >
                <Trophy className="h-4 w-4 mr-2" />
                Leaderboard
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.push("/achievements")}
              >
                <Award className="h-4 w-4 mr-2" />
                Achievements
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <User className="h-4 w-4 text-green-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {session.user?.name}
                </span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => signOut()}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {session.user?.name?.split(' ')[0]}! 👋
          </h2>
          <p className="text-gray-600">
            Keep up the great work with your recycling efforts!
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Points</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{userData.points}</div>
              <p className="text-xs text-muted-foreground">
                Level {userData.level}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Bottles Recycled</CardTitle>
              <Bottle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{userData.totalBottles}</div>
              <p className="text-xs text-muted-foreground">
                {userData.totalWeight.toFixed(1)} kg total
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">CO₂ Saved</CardTitle>
              <Leaf className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{userData.co2Saved.toFixed(1)} kg</div>
              <p className="text-xs text-muted-foreground">
                Environmental impact
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Next Level</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{getLevelProgress(userData.level).toFixed(0)}%</div>
              <p className="text-xs text-muted-foreground">
                Progress to level {userData.level + 1}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Level Progress */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="h-5 w-5 mr-2" />
              Level Progress
            </CardTitle>
            <CardDescription>
              You're currently level {userData.level}. Keep recycling to level up!
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Level {userData.level}</span>
                <span>Level {userData.level + 1}</span>
              </div>
              <Progress value={getLevelProgress(userData.level)} className="h-3" />
              <div className="text-center text-sm text-gray-600">
                {userData.points} points
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Tabs */}
        <Tabs defaultValue="deposit" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="deposit" className="flex items-center">
              <Plus className="h-4 w-4 mr-2" />
              New Deposit
            </TabsTrigger>
            <TabsTrigger value="rewards" className="flex items-center">
              <Gift className="h-4 w-4 mr-2" />
              Rewards
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center">
              <History className="h-4 w-4 mr-2" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="deposit">
            <Card>
              <CardHeader>
                <CardTitle>Record New Bottle Deposit</CardTitle>
                <CardDescription>
                  Add a new plastic bottle deposit to earn points
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Bottle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Ready to Recycle?</h3>
                  <p className="text-gray-600 mb-4">
                    Record your plastic bottle deposits and earn points for rewards!
                  </p>
                  <Button 
                    onClick={() => router.push("/deposit")}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add New Deposit
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rewards">
            <Card>
              <CardHeader>
                <CardTitle>Available Rewards</CardTitle>
                <CardDescription>
                  Redeem your points for exciting rewards
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Gift className="h-16 w-16 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Ready to Redeem?</h3>
                  <p className="text-gray-600 mb-4">
                    Browse our catalog of amazing rewards and redeem your points!
                  </p>
                  <Button 
                    onClick={() => router.push("/rewards")}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Gift className="h-4 w-4 mr-2" />
                    Browse Rewards
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Deposit History</CardTitle>
                <CardDescription>
                  View your recent bottle deposits
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingDeposits ? (
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading deposit history...</p>
                  </div>
                ) : deposits.length === 0 ? (
                  <div className="text-center py-12">
                    <History className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No Deposits Yet</h3>
                    <p className="text-gray-600 mb-4">
                      Start recycling to see your deposit history here.
                    </p>
                    <Button 
                      onClick={() => router.push("/deposit")}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Make Your First Deposit
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {deposits.map((deposit) => (
                      <div key={deposit.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <Bottle className="h-5 w-5 text-green-600" />
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{deposit.bottleType}</span>
                              <Badge variant={deposit.verified ? "default" : "secondary"}>
                                {deposit.verified ? "Verified" : "Pending"}
                              </Badge>
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                              <span className="flex items-center">
                                <Calendar className="h-3 w-3 mr-1" />
                                {new Date(deposit.createdAt).toLocaleDateString()}
                              </span>
                              {deposit.location && (
                                <span className="flex items-center">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  {deposit.location}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600">+{deposit.points} pts</div>
                          <div className="text-sm text-gray-600">
                            {deposit.quantity} bottles • {deposit.weight.toFixed(2)} kg
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}