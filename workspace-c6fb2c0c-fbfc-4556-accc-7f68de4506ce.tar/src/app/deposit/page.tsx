"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  Bottle, 
  ArrowLeft, 
  Upload, 
  MapPin,
  Calculator,
  CheckCircle
} from "lucide-react"

const bottleTypes = [
  { value: "PET", label: "PET (Polyethylene Terephthalate)", points: 10, co2PerKg: 1.5 },
  { value: "HDPE", label: "HDPE (High-Density Polyethylene)", points: 8, co2PerKg: 1.2 },
  { value: "PVC", label: "PVC (Polyvinyl Chloride)", points: 12, co2PerKg: 1.8 },
  { value: "LDPE", label: "LDPE (Low-Density Polyethylene)", points: 6, co2PerKg: 1.0 },
  { value: "PP", label: "PP (Polypropylene)", points: 9, co2PerKg: 1.3 },
  { value: "PS", label: "PS (Polystyrene)", points: 7, co2PerKg: 1.1 },
]

const averageWeights = {
  "PET": 0.025, // 25g per bottle
  "HDPE": 0.030,
  "PVC": 0.035,
  "LDPE": 0.020,
  "PP": 0.028,
  "PS": 0.022,
}

export default function DepositPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [formData, setFormData] = useState({
    bottleType: "",
    quantity: "",
    weight: "",
    location: "",
    receiptUrl: "",
    notes: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState("")

  if (!session) {
    router.push("/auth/signin")
    return null
  }

  const selectedBottleType = bottleTypes.find(bt => bt.value === formData.bottleType)
  
  const calculateWeight = () => {
    if (!formData.bottleType || !formData.quantity) return 0
    const avgWeight = averageWeights[formData.bottleType as keyof typeof averageWeights] || 0.025
    return parseFloat(formData.quantity) * avgWeight
  }

  const calculatePoints = () => {
    if (!selectedBottleType || !formData.quantity) return 0
    const weight = calculateWeight()
    return Math.round(weight * selectedBottleType.points)
  }

  const calculateCO2 = () => {
    if (!selectedBottleType || !formData.quantity) return 0
    const weight = calculateWeight()
    return weight * selectedBottleType.co2PerKg
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    try {
      const weight = formData.weight ? parseFloat(formData.weight) : calculateWeight()
      const points = calculatePoints()
      const co2Saved = calculateCO2()

      const response = await fetch("/api/deposits", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          bottleType: formData.bottleType,
          quantity: parseInt(formData.quantity),
          weight: weight,
          points: points,
          location: formData.location,
          receiptUrl: formData.receiptUrl,
          notes: formData.notes,
        }),
      })

      if (response.ok) {
        setIsSuccess(true)
        setTimeout(() => {
          router.push("/dashboard")
        }, 2000)
      } else {
        const errorData = await response.json()
        setError(errorData.error || "Failed to submit deposit")
      }
    } catch (error) {
      console.error("Error submitting deposit:", error)
      setError("An error occurred while submitting your deposit")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Deposit Submitted!</h2>
              <p className="text-gray-600 mb-4">
                Your bottle deposit has been recorded successfully.
              </p>
              <p className="text-sm text-gray-500">
                Redirecting to dashboard...
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-4">
            <Button 
              variant="ghost" 
              onClick={() => router.back()}
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">New Bottle Deposit</h1>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Bottle Type Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bottle className="h-5 w-5 mr-2" />
                Bottle Information
              </CardTitle>
              <CardDescription>
                Select the type of plastic bottles you're depositing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="bottleType">Bottle Type *</Label>
                <Select 
                  value={formData.bottleType} 
                  onValueChange={(value) => setFormData({...formData, bottleType: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select bottle type" />
                  </SelectTrigger>
                  <SelectContent>
                    {bottleTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center justify-between w-full">
                          <span>{type.label}</span>
                          <Badge variant="secondary" className="ml-2">
                            {type.points} pts/kg
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="quantity">Quantity *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    placeholder="Number of bottles"
                    value={formData.quantity}
                    onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Weight (kg) - Optional</Label>
                  <Input
                    id="weight"
                    type="number"
                    step="0.01"
                    placeholder="Auto-calculated if empty"
                    value={formData.weight}
                    onChange={(e) => setFormData({...formData, weight: e.target.value})}
                  />
                  {formData.bottleType && formData.quantity && !formData.weight && (
                    <p className="text-sm text-gray-500 mt-1">
                      Estimated: {calculateWeight().toFixed(3)} kg
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Points Calculator */}
          {selectedBottleType && formData.quantity && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calculator className="h-5 w-5 mr-2" />
                  Points & Impact Calculator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {calculatePoints()}
                    </div>
                    <div className="text-sm text-gray-600">Points Earned</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {calculateWeight().toFixed(3)} kg
                    </div>
                    <div className="text-sm text-gray-600">Total Weight</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {calculateCO2().toFixed(3)} kg
                    </div>
                    <div className="text-sm text-gray-600">CO₂ Saved</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Location & Receipt */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                Deposit Location
              </CardTitle>
              <CardDescription>
                Where did you deposit the bottles?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="location">Location Name</Label>
                <Input
                  id="location"
                  placeholder="e.g., Walmart Recycling Center, School Collection Point"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="receiptUrl">Receipt Photo URL - Optional</Label>
                <Input
                  id="receiptUrl"
                  type="url"
                  placeholder="https://example.com/receipt.jpg"
                  value={formData.receiptUrl}
                  onChange={(e) => setFormData({...formData, receiptUrl: e.target.value})}
                />
                <p className="text-sm text-gray-500 mt-1">
                  Upload a photo of your receipt as proof of deposit
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Additional Notes */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Notes</CardTitle>
              <CardDescription>
                Any additional information about your deposit
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="e.g., Mixed colors, includes caps, special collection event..."
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                rows={3}
              />
            </CardContent>
          </Card>

          {/* Error Display */}
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Submit Button */}
          <div className="flex justify-end">
            <Button 
              type="submit" 
              disabled={isSubmitting || !formData.bottleType || !formData.quantity}
              size="lg"
              className="bg-green-600 hover:bg-green-700"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Submitting...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Submit Deposit
                </>
              )}
            </Button>
          </div>
        </form>
      </main>
    </div>
  )
}