"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  ArrowLeft, 
  Award, 
  Star, 
  Target,
  TrendingUp,
  Calendar,
  CheckCircle,
  Lock,
  Zap,
  Leaf,
  Recycle,
  Crown,
  Trophy,
  Fire,
  Gem,
  Users,
  Gift
} from "lucide-react"

interface Achievement {
  id: string
  name: string
  description: string
  icon?: string
  condition: string
  points: number
  category: string
  createdAt: string
}

interface UserAchievement {
  id: string
  userId: string
  achievementId: string
  earnedAt: string
  progress: number
  achievement: Achievement
}

export default function AchievementsPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([])
  const [userStats, setUserStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!session) {
      router.push("/auth/signin")
      return
    }

    const fetchData = async () => {
      try {
        // Fetch achievements
        const achievementsResponse = await fetch("/api/achievements")
        if (achievementsResponse.ok) {
          const achievementsData = await achievementsResponse.json()
          setAchievements(achievementsData)
        }

        // Fetch user achievements
        const userAchievementsResponse = await fetch("/api/user/achievements")
        if (userAchievementsResponse.ok) {
          const userAchievementsData = await userAchievementsResponse.json()
          setUserAchievements(userAchievementsData)
        }

        // Fetch user stats for progress calculation
        const userResponse = await fetch("/api/user/profile")
        if (userResponse.ok) {
          const userData = await userResponse.json()
          setUserStats(userData)
        }

      } catch (error) {
        console.error("Error fetching achievements data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [session, router])

  const calculateProgress = (achievement: Achievement) => {
    if (!userStats) return 0

    const condition = JSON.parse(achievement.condition)
    
    switch (condition.type) {
      case 'bottles':
        return Math.min((userStats.totalBottles / condition.target) * 100, 100)
      case 'points':
        return Math.min((userStats.points / condition.target) * 100, 100)
      case 'level':
        return Math.min((userStats.level / condition.target) * 100, 100)
      case 'co2':
        return Math.min((userStats.co2Saved / condition.target) * 100, 100)
      case 'deposits':
        // This would need deposit count, using totalBottles as proxy
        return Math.min((userStats.totalBottles / condition.target) * 100, 100)
      default:
        return 0
    }
  }

  const isAchievementEarned = (achievementId: string) => {
    return userAchievements.some(ua => ua.achievementId === achievementId)
  }

  const getAchievementIcon = (icon?: string) => {
    switch (icon) {
      case 'star': return <Star className="h-6 w-6" />
      case 'target': return <Target className="h-6 w-6" />
      case 'trending': return <TrendingUp className="h-6 w-6" />
      case 'zap': return <Zap className="h-6 w-6" />
      case 'leaf': return <Leaf className="h-6 w-6" />
      case 'recycle': return <Recycle className="h-6 w-6" />
      case 'crown': return <Crown className="h-6 w-6" />
      case 'trophy': return <Trophy className="h-6 w-6" />
      case 'fire': return <Fire className="h-6 w-6" />
      case 'gem': return <Gem className="h-6 w-6" />
      case 'users': return <Users className="h-6 w-6" />
      case 'gift': return <Gift className="h-6 w-6" />
      default: return <Award className="h-6 w-6" />
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Milestones': return <Target className="h-5 w-5" />
      case 'Consistency': return <Calendar className="h-5 w-5" />
      case 'Impact': return <Leaf className="h-5 w-5" />
      case 'Social': return <Users className="h-5 w-5" />
      default: return <Star className="h-5 w-5" />
    }
  }

  const categories = ["all", "Milestones", "Consistency", "Impact", "Social"]

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  const earnedAchievements = userAchievements.length
  const totalAchievements = achievements.length
  const completionPercentage = totalAchievements > 0 ? (earnedAchievements / totalAchievements) * 100 : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-4">
            <Button 
              variant="ghost" 
              onClick={() => router.back()}
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Achievements</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Achievement Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Award className="h-5 w-5 mr-2 text-purple-600" />
              Your Achievement Progress
            </CardTitle>
            <CardDescription>
              Track your progress and unlock new achievements
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-1">
                  {earnedAchievements}
                </div>
                <div className="text-sm text-gray-600">Earned</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-600 mb-1">
                  {totalAchievements}
                </div>
                <div className="text-sm text-gray-600">Total</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-1">
                  {completionPercentage.toFixed(0)}%
                </div>
                <div className="text-sm text-gray-600">Complete</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-1">
                  {userAchievements.reduce((sum, ua) => sum + ua.achievement.points, 0)}
                </div>
                <div className="text-sm text-gray-600">Bonus Points</div>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={completionPercentage} className="h-3" />
              <div className="text-center text-sm text-gray-600 mt-2">
                {earnedAchievements} of {totalAchievements} achievements unlocked
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Achievement Categories */}
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            {categories.map((category) => (
              <TabsTrigger key={category} value={category.toLowerCase()} className="flex items-center">
                {getCategoryIcon(category === "all" ? "Milestones" : category)}
                <span className="ml-2 hidden sm:inline">{category}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent key={category} value={category.toLowerCase()}>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {achievements
                  .filter(achievement => category === "all" || achievement.category === category)
                  .map((achievement) => {
                    const isEarned = isAchievementEarned(achievement.id)
                    const progress = isEarned ? 100 : calculateProgress(achievement)
                    const userAchievement = userAchievements.find(ua => ua.achievementId === achievement.id)

                    return (
                      <Card 
                        key={achievement.id} 
                        className={`transition-all hover:shadow-lg ${
                          isEarned 
                            ? 'border-2 border-yellow-300 bg-gradient-to-br from-yellow-50 to-orange-50' 
                            : 'border border-gray-200'
                        }`}
                      >
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex items-center space-x-3">
                              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                                isEarned 
                                  ? 'bg-gradient-to-r from-yellow-400 to-orange-400 text-white' 
                                  : 'bg-gray-100 text-gray-400'
                              }`}>
                                {getAchievementIcon(achievement.icon)}
                              </div>
                              <div className="flex-1">
                                <CardTitle className={`text-lg ${isEarned ? 'text-yellow-800' : 'text-gray-700'}`}>
                                  {achievement.name}
                                </CardTitle>
                                <CardDescription className="text-sm">
                                  {achievement.description}
                                </CardDescription>
                              </div>
                            </div>
                            <div className="flex flex-col items-end space-y-1">
                              {isEarned ? (
                                <CheckCircle className="h-5 w-5 text-green-600" />
                              ) : (
                                <Lock className="h-5 w-5 text-gray-400" />
                              )}
                              <Badge variant="secondary" className="text-xs">
                                {achievement.points} pts
                              </Badge>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span>Progress</span>
                                <span>{progress.toFixed(0)}%</span>
                              </div>
                              <Progress value={progress} className="h-2" />
                            </div>
                            
                            {isEarned && userAchievement && (
                              <div className="flex items-center text-sm text-green-600">
                                <Calendar className="h-3 w-3 mr-1" />
                                Earned on {new Date(userAchievement.earnedAt).toLocaleDateString()}
                              </div>
                            )}
                            
                            <Badge variant="outline" className="text-xs">
                              {achievement.category}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Achievement Tips */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="h-5 w-5 mr-2 text-yellow-600" />
              How to Earn Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-2 text-green-700">Milestones</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Recycle specific numbers of bottles</li>
                  <li>• Reach certain point thresholds</li>
                  <li>• Achieve higher levels</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-2 text-blue-700">Impact</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Save specific amounts of CO₂</li>
                  <li>• Recycle different types of plastic</li>
                  <li>• Make consistent deposits over time</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}