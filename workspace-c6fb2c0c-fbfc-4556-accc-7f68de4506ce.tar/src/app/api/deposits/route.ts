import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { bottleType, quantity, weight, points, location, receiptUrl, notes } = body

    // Validate required fields
    if (!bottleType || !quantity || !weight || !points) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Get user from database
    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Calculate CO2 saved (rough estimate: 1.5kg CO2 per kg of plastic)
    const co2Saved = weight * 1.5

    // Create the deposit
    const deposit = await db.bottleDeposit.create({
      data: {
        userId: user.id,
        bottleType,
        quantity: parseInt(quantity),
        weight: parseFloat(weight),
        points: parseInt(points),
        location: location || null,
        receiptUrl: receiptUrl || null,
        verified: false, // Deposits start as unverified
      }
    })

    // Update user stats
    const updatedUser = await db.user.update({
      where: { id: user.id },
      data: {
        points: user.points + parseInt(points),
        totalBottles: user.totalBottles + parseInt(quantity),
        totalWeight: user.totalWeight + parseFloat(weight),
        co2Saved: user.co2Saved + co2Saved,
      }
    })

    // Check and update user level based on new points
    const levelThresholds = [0, 100, 300, 600, 1000, 1500, 2100, 2800, 3600, 4500]
    let newLevel = 1
    for (let i = levelThresholds.length - 1; i >= 0; i--) {
      if (updatedUser.points >= levelThresholds[i]) {
        newLevel = i + 1
        break
      }
    }

    if (newLevel > user.level) {
      await db.user.update({
        where: { id: user.id },
        data: { level: newLevel }
      })
    }

    return NextResponse.json({ 
      success: true, 
      deposit: {
        id: deposit.id,
        points: deposit.points,
        newLevel: newLevel > user.level ? newLevel : null
      }
    })

  } catch (error) {
    console.error("Error creating deposit:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const deposits = await db.bottleDeposit.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 50 // Limit to last 50 deposits
    })

    return NextResponse.json(deposits)
  } catch (error) {
    console.error("Error fetching deposits:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}