import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const userRewards = await db.userReward.findMany({
      where: { userId: user.id },
      include: {
        reward: true
      },
      orderBy: { redeemedAt: 'desc' }
    })

    return NextResponse.json(userRewards)
  } catch (error) {
    console.error("Error fetching user rewards:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { rewardId, pointsUsed } = body

    if (!rewardId || !pointsUsed) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Get user from database
    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Check if user has enough points
    if (user.points < pointsUsed) {
      return NextResponse.json({ error: "Insufficient points" }, { status: 400 })
    }

    // Get the reward
    const reward = await db.reward.findUnique({
      where: { id: rewardId }
    })

    if (!reward || !reward.isActive) {
      return NextResponse.json({ error: "Reward not available" }, { status: 404 })
    }

    // Check if reward is in stock
    if (reward.stock <= 0) {
      return NextResponse.json({ error: "Reward out of stock" }, { status: 400 })
    }

    // Create user reward record
    const userReward = await db.userReward.create({
      data: {
        userId: user.id,
        rewardId: rewardId,
        pointsUsed: parseInt(pointsUsed),
        status: "pending",
      }
    })

    // Update user points
    await db.user.update({
      where: { id: user.id },
      data: {
        points: user.points - parseInt(pointsUsed)
      }
    })

    // Update reward stock
    await db.reward.update({
      where: { id: rewardId },
      data: {
        stock: reward.stock - 1
      }
    })

    return NextResponse.json({ 
      success: true, 
      userReward: {
        id: userReward.id,
        pointsUsed: userReward.pointsUsed,
        status: userReward.status,
        redeemedAt: userReward.redeemedAt
      }
    })

  } catch (error) {
    console.error("Error creating user reward:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}