import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const userAchievements = await db.userAchievement.findMany({
      where: { userId: user.id },
      include: {
        achievement: true
      },
      orderBy: { earnedAt: 'desc' }
    })

    return NextResponse.json(userAchievements)
  } catch (error) {
    console.error("Error fetching user achievements:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { achievementId } = body

    if (!achievementId) {
      return NextResponse.json({ error: "Missing achievement ID" }, { status: 400 })
    }

    // Get user from database
    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Check if achievement exists
    const achievement = await db.achievement.findUnique({
      where: { id: achievementId }
    })

    if (!achievement) {
      return NextResponse.json({ error: "Achievement not found" }, { status: 404 })
    }

    // Check if user already has this achievement
    const existingUserAchievement = await db.userAchievement.findUnique({
      where: {
        userId_achievementId: {
          userId: user.id,
          achievementId: achievementId
        }
      }
    })

    if (existingUserAchievement) {
      return NextResponse.json({ error: "Achievement already earned" }, { status: 400 })
    }

    // Create user achievement record
    const userAchievement = await db.userAchievement.create({
      data: {
        userId: user.id,
        achievementId: achievementId,
        progress: 100,
      }
    })

    // Award bonus points to user
    await db.user.update({
      where: { id: user.id },
      data: {
        points: user.points + achievement.points
      }
    })

    return NextResponse.json({ 
      success: true, 
      userAchievement: {
        id: userAchievement.id,
        achievement: achievement,
        earnedAt: userAchievement.earnedAt,
        bonusPoints: achievement.points
      }
    })

  } catch (error) {
    console.error("Error creating user achievement:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}