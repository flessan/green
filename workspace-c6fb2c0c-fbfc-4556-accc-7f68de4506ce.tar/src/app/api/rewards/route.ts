import { NextResponse } from "next/server"
import { db } from "@/lib/db"

// Sample rewards data - in a real app, this would be managed through an admin panel
const sampleRewards = [
  {
    id: "1",
    name: "Wireless Bluetooth Headphones",
    description: "High-quality wireless headphones with noise cancellation",
    points: 500,
    category: "Electronics",
    stock: 10,
    isActive: true,
  },
  {
    id: "2", 
    name: "$10 Amazon Gift Card",
    description: "Digital gift card for Amazon purchases",
    points: 300,
    category: "Vouchers",
    stock: 50,
    isActive: true,
  },
  {
    id: "3",
    name: "Reusable Water Bottle Set",
    description: "Set of 3 eco-friendly stainless steel water bottles",
    points: 200,
    category: "Eco-friendly",
    stock: 25,
    isActive: true,
  },
  {
    id: "4",
    name: "Portable Phone Charger",
    description: "10000mAh portable power bank with fast charging",
    points: 400,
    category: "Electronics",
    stock: 15,
    isActive: true,
  },
  {
    id: "5",
    name: "Organic Cotton Tote Bag",
    description: "Sustainable and stylish organic cotton shopping bag",
    points: 150,
    category: "Eco-friendly",
    stock: 100,
    isActive: true,
  },
  {
    id: "6",
    name: "Coffee Shop Gift Card",
    description: "$15 gift card for popular coffee chains",
    points: 250,
    category: "Vouchers",
    stock: 30,
    isActive: true,
  },
  {
    id: "7",
    name: "Gardening Tool Set",
    description: "Complete set of essential gardening tools",
    points: 350,
    category: "Home & Garden",
    stock: 20,
    isActive: true,
  },
  {
    id: "8",
    name: "Yoga Mat",
    description: "Non-slip eco-friendly yoga mat with carrying strap",
    points: 180,
    category: "Sports & Outdoors",
    stock: 40,
    isActive: true,
  },
]

export async function GET() {
  try {
    // Check if rewards exist in database, if not seed them
    const existingRewards = await db.reward.findMany()
    
    if (existingRewards.length === 0) {
      // Seed the database with sample rewards
      await db.reward.createMany({
        data: sampleRewards,
      })
    }

    const rewards = await db.reward.findMany({
      where: { isActive: true },
      orderBy: { points: 'asc' }
    })

    return NextResponse.json(rewards)
  } catch (error) {
    console.error("Error fetching rewards:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, description, points, category, stock, isActive } = body

    // Validate required fields
    if (!name || !description || !points || !category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const reward = await db.reward.create({
      data: {
        name,
        description,
        points: parseInt(points),
        category,
        stock: parseInt(stock) || 0,
        isActive: isActive !== false,
      }
    })

    return NextResponse.json(reward)
  } catch (error) {
    console.error("Error creating reward:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}