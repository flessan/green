import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET() {
  try {
    // Get all users with their stats, ordered by points for all-time ranking
    const allTimeUsers = await db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        points: true,
        totalBottles: true,
        totalWeight: true,
        co2Saved: true,
        level: true,
        createdAt: true,
      },
      orderBy: {
        points: 'desc'
      },
      take: 100 // Limit to top 100 users
    })

    // Add rank to each user
    const allTimeWithRank = allTimeUsers.map((user, index) => ({
      ...user,
      rank: index + 1
    }))

    // For monthly and weekly data, we'll simulate based on total stats
    // In a real application, you would filter by date ranges
    const monthlyUsers = allTimeUsers
      .map(user => ({
        ...user,
        // Simulate monthly data by taking a portion of total stats
        points: Math.floor(user.points * 0.3), // Assume 30% of points earned this month
        totalBottles: Math.floor(user.totalBottles * 0.35),
        totalWeight: user.totalWeight * 0.35,
        co2Saved: user.co2Saved * 0.35,
      }))
      .sort((a, b) => b.points - a.points)
      .slice(0, 50)
      .map((user, index) => ({
        ...user,
        rank: index + 1
      }))

    const weeklyUsers = allTimeUsers
      .map(user => ({
        ...user,
        // Simulate weekly data by taking a smaller portion of total stats
        points: Math.floor(user.points * 0.1), // Assume 10% of points earned this week
        totalBottles: Math.floor(user.totalBottles * 0.12),
        totalWeight: user.totalWeight * 0.12,
        co2Saved: user.co2Saved * 0.12,
      }))
      .sort((a, b) => b.points - a.points)
      .slice(0, 30)
      .map((user, index) => ({
        ...user,
        rank: index + 1
      }))

    return NextResponse.json({
      weekly: weeklyUsers,
      monthly: monthlyUsers,
      allTime: allTimeWithRank
    })

  } catch (error) {
    console.error("Error fetching leaderboard data:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}