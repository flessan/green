import { NextResponse } from "next/server"
import { db } from "@/lib/db"

// Sample achievements data
const sampleAchievements = [
  {
    id: "first-deposit",
    name: "First Steps",
    description: "Make your first bottle deposit",
    icon: "star",
    condition: JSON.stringify({ type: "deposits", target: 1 }),
    points: 10,
    category: "Milestones",
  },
  {
    id: "bottles-10",
    name: "Double Digits",
    description: "Recycle 10 bottles",
    icon: "target",
    condition: JSON.stringify({ type: "bottles", target: 10 }),
    points: 25,
    category: "Milestones",
  },
  {
    id: "bottles-50",
    name: "Half Century",
    description: "Recycle 50 bottles",
    icon: "trophy",
    condition: JSON.stringify({ type: "bottles", target: 50 }),
    points: 100,
    category: "Milestones",
  },
  {
    id: "bottles-100",
    name: "Century Club",
    description: "Recycle 100 bottles",
    icon: "crown",
    condition: JSON.stringify({ type: "bottles", target: 100 }),
    points: 250,
    category: "Milestones",
  },
  {
    id: "bottles-500",
    name: "Bottle Master",
    description: "Recycle 500 bottles",
    icon: "gem",
    condition: JSON.stringify({ type: "bottles", target: 500 }),
    points: 1000,
    category: "Milestones",
  },
  {
    id: "points-100",
    name: "Point Collector",
    description: "Earn 100 points",
    icon: "star",
    condition: JSON.stringify({ type: "points", target: 100 }),
    points: 20,
    category: "Milestones",
  },
  {
    id: "points-500",
    name: "Point Hero",
    description: "Earn 500 points",
    icon: "zap",
    condition: JSON.stringify({ type: "points", target: 500 }),
    points: 100,
    category: "Milestones",
  },
  {
    id: "points-1000",
    name: "Point Legend",
    description: "Earn 1000 points",
    icon: "fire",
    condition: JSON.stringify({ type: "points", target: 1000 }),
    points: 200,
    category: "Milestones",
  },
  {
    id: "level-5",
    name: "Rising Star",
    description: "Reach level 5",
    icon: "trending",
    condition: JSON.stringify({ type: "level", target: 5 }),
    points: 150,
    category: "Milestones",
  },
  {
    id: "level-10",
    name: "Eco Warrior",
    description: "Reach level 10",
    icon: "crown",
    condition: JSON.stringify({ type: "level", target: 10 }),
    points: 500,
    category: "Milestones",
  },
  {
    id: "co2-5",
    name: "Carbon Fighter",
    description: "Save 5kg of CO₂",
    icon: "leaf",
    condition: JSON.stringify({ type: "co2", target: 5 }),
    points: 75,
    category: "Impact",
  },
  {
    id: "co2-25",
    name: "Climate Champion",
    description: "Save 25kg of CO₂",
    icon: "leaf",
    condition: JSON.stringify({ type: "co2", target: 25 }),
    points: 300,
    category: "Impact",
  },
  {
    id: "co2-50",
    name: "Planet Saver",
    description: "Save 50kg of CO₂",
    icon: "leaf",
    condition: JSON.stringify({ type: "co2", target: 50 }),
    points: 750,
    category: "Impact",
  },
  {
    id: "consistent-week",
    name: "Weekly Warrior",
    description: "Make deposits for 7 consecutive days",
    icon: "calendar",
    condition: JSON.stringify({ type: "consistency", target: 7, period: "daily" }),
    points: 150,
    category: "Consistency",
  },
  {
    id: "consistent-month",
    name: "Monthly Master",
    description: "Make deposits for 30 consecutive days",
    icon: "calendar",
    condition: JSON.stringify({ type: "consistency", target: 30, period: "daily" }),
    points: 500,
    category: "Consistency",
  },
  {
    id: "social-sharer",
    name: "Eco Ambassador",
    description: "Share your impact on social media",
    icon: "users",
    condition: JSON.stringify({ type: "social", target: 1, action: "share" }),
    points: 50,
    category: "Social",
  },
  {
    id: "reward-redeemer",
    name: "Reward Seeker",
    description: "Redeem your first reward",
    icon: "gift",
    condition: JSON.stringify({ type: "rewards", target: 1 }),
    points: 30,
    category: "Milestones",
  },
]

export async function GET() {
  try {
    // Check if achievements exist in database, if not seed them
    const existingAchievements = await db.achievement.findMany()
    
    if (existingAchievements.length === 0) {
      // Seed the database with sample achievements
      await db.achievement.createMany({
        data: sampleAchievements,
      })
    }

    const achievements = await db.achievement.findMany({
      orderBy: { category: 'asc' }
    })

    return NextResponse.json(achievements)
  } catch (error) {
    console.error("Error fetching achievements:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, description, icon, condition, points, category } = body

    // Validate required fields
    if (!name || !description || !condition || !points || !category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const achievement = await db.achievement.create({
      data: {
        name,
        description,
        icon,
        condition: typeof condition === 'string' ? condition : JSON.stringify(condition),
        points: parseInt(points),
        category,
      }
    })

    return NextResponse.json(achievement)
  } catch (error) {
    console.error("Error creating achievement:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}