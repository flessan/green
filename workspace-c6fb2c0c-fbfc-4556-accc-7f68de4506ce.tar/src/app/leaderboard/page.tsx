"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { 
  ArrowLeft, 
  Trophy, 
  Award, 
  TrendingUp,
  Calendar,
  Bottle,
  Leaf,
  Star,
  Crown,
  Medal,
  Users,
  Target
} from "lucide-react"

interface LeaderboardEntry {
  id: string
  name: string
  email?: string
  points: number
  totalBottles: number
  totalWeight: number
  co2Saved: number
  level: number
  rank: number
}

interface TimeFrameData {
  monthly: LeaderboardEntry[]
  allTime: LeaderboardEntry[]
  weekly: LeaderboardEntry[]
}

export default function LeaderboardPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [leaderboardData, setLeaderboardData] = useState<TimeFrameData | null>(null)
  const [userRank, setUserRank] = useState<LeaderboardEntry | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeFrame, setTimeFrame] = useState<"weekly" | "monthly" | "allTime">("allTime")

  useEffect(() => {
    if (!session) {
      router.push("/auth/signin")
      return
    }

    const fetchLeaderboardData = async () => {
      try {
        const response = await fetch("/api/leaderboard")
        if (response.ok) {
          const data = await response.json()
          setLeaderboardData(data)
          
          // Find current user's rank
          if (session.user?.email) {
            const userEntry = data.allTime.find((entry: LeaderboardEntry) => 
              entry.email === session.user?.email
            )
            setUserRank(userEntry || null)
          }
        }
      } catch (error) {
        console.error("Error fetching leaderboard data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchLeaderboardData()
  }, [session, router])

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-yellow-500" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />
      case 3:
        return <Medal className="h-6 w-6 text-orange-600" />
      default:
        return <div className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center text-xs font-bold text-gray-600">
          {rank}
        </div>
    }
  }

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-yellow-400 to-yellow-600 text-white"
      case 2:
        return "bg-gradient-to-r from-gray-300 to-gray-500 text-white"
      case 3:
        return "bg-gradient-to-r from-orange-400 to-orange-600 text-white"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const getCurrentLeaderboard = () => {
    if (!leaderboardData) return []
    return leaderboardData[timeFrame] || []
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!leaderboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Unable to load leaderboard</h2>
          <p className="text-gray-600">Please try again later</p>
        </div>
      </div>
    )
  }

  const currentLeaderboard = getCurrentLeaderboard()

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-red-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                onClick={() => router.back()}
                className="mr-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">Leaderboard</h1>
            </div>
            <Select value={timeFrame} onValueChange={(value: any) => setTimeFrame(value)}>
              <SelectTrigger className="w-40">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weekly">This Week</SelectItem>
                <SelectItem value="monthly">This Month</SelectItem>
                <SelectItem value="allTime">All Time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* User's Rank Card */}
        {userRank && (
          <Card className="mb-8 border-l-4 border-l-green-500">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Star className="h-5 w-5 mr-2 text-green-600" />
                Your Ranking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-5 gap-4">
                <div className="text-center">
                  <div className={`w-12 h-12 ${getRankBadgeColor(userRank.rank)} rounded-full flex items-center justify-center mx-auto mb-2 font-bold`}>
                    #{userRank.rank}
                  </div>
                  <div className="text-sm text-gray-600">Rank</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-1">
                    {userRank.points}
                  </div>
                  <div className="text-sm text-gray-600">Points</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    {userRank.totalBottles}
                  </div>
                  <div className="text-sm text-gray-600">Bottles</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    {userRank.co2Saved.toFixed(1)}kg
                  </div>
                  <div className="text-sm text-gray-600">CO₂ Saved</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600 mb-1">
                    {userRank.level}
                  </div>
                  <div className="text-sm text-gray-600">Level</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Leaderboard Tabs */}
        <Tabs defaultValue="top" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="top">Top Recyclers</TabsTrigger>
            <TabsTrigger value="impact">Environmental Heroes</TabsTrigger>
            <TabsTrigger value="levels">Level Champions</TabsTrigger>
          </TabsList>

          <TabsContent value="top">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="h-5 w-5 mr-2 text-yellow-600" />
                  Top Recyclers - {timeFrame === "weekly" ? "This Week" : timeFrame === "monthly" ? "This Month" : "All Time"}
                </CardTitle>
                <CardDescription>
                  Ranked by total points earned from recycling
                </CardDescription>
              </CardHeader>
              <CardContent>
                {currentLeaderboard.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No recyclers yet</h3>
                    <p className="text-gray-600 mb-4">
                      Be the first to start recycling and climb the leaderboard!
                    </p>
                    <Button 
                      onClick={() => router.push("/deposit")}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Start Recycling
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {currentLeaderboard.slice(0, 20).map((entry, index) => (
                      <div 
                        key={entry.id} 
                        className={`flex items-center justify-between p-4 rounded-lg transition-all hover:shadow-md ${
                          entry.email === session.user?.email 
                            ? 'bg-green-50 border-2 border-green-200' 
                            : 'bg-white border'
                        }`}
                      >
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center">
                            {getRankIcon(entry.rank)}
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full flex items-center justify-center text-white font-bold">
                              {entry.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-medium">
                                {entry.name}
                                {entry.email === session.user?.email && (
                                  <Badge variant="secondary" className="ml-2">You</Badge>
                                )}
                              </div>
                              <div className="text-sm text-gray-600">
                                Level {entry.level}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-6 text-right">
                          <div>
                            <div className="font-semibold text-blue-600">
                              {entry.points.toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-600">points</div>
                          </div>
                          <div>
                            <div className="font-semibold text-green-600">
                              {entry.totalBottles.toLocaleString()}
                            </div>
                            <div className="text-xs text-gray-600">bottles</div>
                          </div>
                          <div>
                            <div className="font-semibold text-purple-600">
                              {entry.co2Saved.toFixed(1)}kg
                            </div>
                            <div className="text-xs text-gray-600">CO₂ saved</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="impact">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Leaf className="h-5 w-5 mr-2 text-green-600" />
                  Environmental Heroes
                </CardTitle>
                <CardDescription>
                  Ranked by CO₂ saved through recycling efforts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {currentLeaderboard
                    .sort((a, b) => b.co2Saved - a.co2Saved)
                    .slice(0, 10)
                    .map((entry, index) => (
                      <div 
                        key={entry.id} 
                        className={`flex items-center justify-between p-4 rounded-lg ${
                          entry.email === session.user?.email 
                            ? 'bg-green-50 border-2 border-green-200' 
                            : 'bg-white border'
                        }`}
                      >
                        <div className="flex items-center space-x-4">
                          <div className={`w-8 h-8 ${getRankBadgeColor(index + 1)} rounded-full flex items-center justify-center font-bold text-sm`}>
                            {index + 1}
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-blue-400 rounded-full flex items-center justify-center text-white font-bold">
                              {entry.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-medium">
                                {entry.name}
                                {entry.email === session.user?.email && (
                                  <Badge variant="secondary" className="ml-2">You</Badge>
                                )}
                              </div>
                              <div className="text-sm text-gray-600">
                                {entry.totalBottles} bottles recycled
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600 text-lg">
                            {entry.co2Saved.toFixed(1)} kg
                          </div>
                          <div className="text-xs text-gray-600">CO₂ saved</div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="levels">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="h-5 w-5 mr-2 text-purple-600" />
                  Level Champions
                </CardTitle>
                <CardDescription>
                  Users who have reached the highest levels through consistent recycling
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {currentLeaderboard
                    .sort((a, b) => b.level - a.level)
                    .filter(entry => entry.level > 1)
                    .slice(0, 10)
                    .map((entry, index) => (
                      <div 
                        key={entry.id} 
                        className={`flex items-center justify-between p-4 rounded-lg ${
                          entry.email === session.user?.email 
                            ? 'bg-green-50 border-2 border-green-200' 
                            : 'bg-white border'
                        }`}
                      >
                        <div className="flex items-center space-x-4">
                          <div className={`w-8 h-8 ${getRankBadgeColor(index + 1)} rounded-full flex items-center justify-center font-bold text-sm`}>
                            {index + 1}
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center text-white font-bold">
                              {entry.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-medium">
                                {entry.name}
                                {entry.email === session.user?.email && (
                                  <Badge variant="secondary" className="ml-2">You</Badge>
                                )}
                              </div>
                              <div className="text-sm text-gray-600">
                                {entry.points.toLocaleString()} points
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-2">
                            <Badge variant="default" className="bg-purple-600">
                              Level {entry.level}
                            </Badge>
                            <Target className="h-4 w-4 text-purple-600" />
                          </div>
                          <div className="text-xs text-gray-600 mt-1">
                            {entry.totalBottles} bottles
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}