"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  ArrowLeft, 
  Leaf, 
  Droplets, 
  Wind,
  TreePine,
  Recycle,
  Globe,
  TrendingUp,
  Award,
  Lightbulb,
  BarChart3
} from "lucide-react"

interface ImpactData {
  totalBottles: number
  totalWeight: number
  co2Saved: number
  waterSaved: number
  energySaved: number
  treesEquivalent: number
}

interface GlobalStats {
  totalUsers: number
  totalBottles: number
  totalCo2Saved: number
  topRecyclers: Array<{
    name: string
    bottles: number
    co2Saved: number
  }>
}

export default function ImpactPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [personalImpact, setPersonalImpact] = useState<ImpactData | null>(null)
  const [globalStats, setGlobalStats] = useState<GlobalStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!session) {
      router.push("/auth/signin")
      return
    }

    const fetchData = async () => {
      try {
        // Fetch personal impact data
        const userResponse = await fetch("/api/user/profile")
        if (userResponse.ok) {
          const userData = await userResponse.json()
          
          // Calculate additional impact metrics
          const waterSaved = userData.totalWeight * 150 // 150L water saved per kg of plastic
          const energySaved = userData.totalWeight * 5.8 // 5.8 kWh energy saved per kg of plastic
          const treesEquivalent = userData.co2Saved / 21.77 // 21.77 kg CO2 absorbed by tree per year
          
          setPersonalImpact({
            totalBottles: userData.totalBottles,
            totalWeight: userData.totalWeight,
            co2Saved: userData.co2Saved,
            waterSaved,
            energySaved,
            treesEquivalent
          })
        }

        // Fetch global stats (mock data for now)
        setGlobalStats({
          totalUsers: 52420,
          totalBottles: 1250000,
          totalCo2Saved: 31250,
          topRecyclers: [
            { name: "Eco Warrior", bottles: 1250, co2Saved: 31.25 },
            { name: "Green Hero", bottles: 980, co2Saved: 24.5 },
            { name: "Recycle Pro", bottles: 750, co2Saved: 18.75 },
            { name: "Nature Lover", bottles: 620, co2Saved: 15.5 },
            { name: "Planet Saver", bottles: 580, co2Saved: 14.5 }
          ]
        })

      } catch (error) {
        console.error("Error fetching impact data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [session, router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!personalImpact || !globalStats) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Leaf className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Unable to load impact data</h2>
          <p className="text-gray-600">Please try again later</p>
        </div>
      </div>
    )
  }

  const impactMetrics = [
    {
      icon: <Recycle className="h-6 w-6" />,
      title: "Bottles Recycled",
      value: personalImpact.totalBottles.toLocaleString(),
      unit: "bottles",
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      description: "Plastic bottles diverted from landfills"
    },
    {
      icon: <Leaf className="h-6 w-6" />,
      title: "CO₂ Saved",
      value: personalImpact.co2Saved.toFixed(1),
      unit: "kg",
      color: "text-green-600",
      bgColor: "bg-green-100",
      description: "Greenhouse gases prevented from entering atmosphere"
    },
    {
      icon: <Droplets className="h-6 w-6" />,
      title: "Water Saved",
      value: personalImpact.waterSaved.toLocaleString(),
      unit: "liters",
      color: "text-cyan-600",
      bgColor: "bg-cyan-100",
      description: "Water conserved through recycling"
    },
    {
      icon: <Wind className="h-6 w-6" />,
      title: "Energy Saved",
      value: personalImpact.energySaved.toFixed(1),
      unit: "kWh",
      color: "text-yellow-600",
      bgColor: "bg-yellow-100",
      description: "Energy conserved vs. producing new plastic"
    },
    {
      icon: <TreePine className="h-6 w-6" />,
      title: "Trees Equivalent",
      value: personalImpact.treesEquivalent.toFixed(1),
      unit: "trees",
      color: "text-green-700",
      bgColor: "bg-green-200",
      description: "Equivalent to trees absorbing CO₂ for one year"
    }
  ]

  const recyclingFacts = [
    {
      title: "Plastic Bottle Facts",
      facts: [
        "It takes up to 1,000 years for a plastic bottle to decompose in a landfill",
        "Recycling plastic uses 88% less energy than making plastic from raw materials",
        "1 ton of recycled plastic saves 5,774 kWh of energy",
        "Recycling 1 plastic bottle can save enough energy to power a 60W light bulb for 3 hours"
      ]
    },
    {
      title: "Environmental Impact",
      facts: [
        "For every 1 ton of plastic recycled, 7.4 cubic yards of landfill space is saved",
        "Recycling reduces greenhouse gas emissions by reducing the need for extracting and refining new materials",
        "The recycling industry creates 10 times more jobs than landfilling",
        "Plastic recycling helps reduce ocean pollution and protects marine life"
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-4">
            <Button 
              variant="ghost" 
              onClick={() => router.back()}
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Environmental Impact</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="personal">My Impact</TabsTrigger>
            <TabsTrigger value="global">Global Impact</TabsTrigger>
            <TabsTrigger value="learn">Learn More</TabsTrigger>
          </TabsList>

          <TabsContent value="personal">
            <div className="space-y-8">
              {/* Personal Impact Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Leaf className="h-5 w-5 mr-2 text-green-600" />
                    Your Environmental Impact
                  </CardTitle>
                  <CardDescription>
                    See the positive difference you're making through recycling
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {impactMetrics.map((metric, index) => (
                      <div key={index} className="text-center">
                        <div className={`w-16 h-16 ${metric.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                          <div className={metric.color}>
                            {metric.icon}
                          </div>
                        </div>
                        <div className="text-3xl font-bold text-gray-900 mb-1">
                          {metric.value}
                        </div>
                        <div className="text-sm text-gray-600 mb-2">
                          {metric.unit}
                        </div>
                        <div className="text-xs text-gray-500">
                          {metric.description}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Progress Towards Goals */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
                    Recycling Goals Progress
                  </CardTitle>
                  <CardDescription>
                    Track your progress towards environmental milestones
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Eco Warrior (1000 bottles)</span>
                      <Badge variant="outline">
                        {personalImpact.totalBottles}/1000
                      </Badge>
                    </div>
                    <Progress value={(personalImpact.totalBottles / 1000) * 100} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Carbon Saver (50kg CO₂)</span>
                      <Badge variant="outline">
                        {personalImpact.co2Saved.toFixed(1)}/50 kg
                      </Badge>
                    </div>
                    <Progress value={(personalImpact.co2Saved / 50) * 100} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Water Guardian (10,000L)</span>
                      <Badge variant="outline">
                        {personalImpact.waterSaved.toLocaleString()}/10,000 L
                      </Badge>
                    </div>
                    <Progress value={(personalImpact.waterSaved / 10000) * 100} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              {/* Achievement Badges */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="h-5 w-5 mr-2 text-purple-600" />
                    Environmental Achievements
                  </CardTitle>
                  <CardDescription>
                    Badges you've earned for your recycling efforts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                        <Recycle className="h-8 w-8 text-green-600" />
                      </div>
                      <div className="text-sm font-medium">First Steps</div>
                      <div className="text-xs text-gray-500">First deposit</div>
                    </div>
                    
                    {personalImpact.totalBottles >= 10 && (
                      <div className="text-center">
                        <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                          <BarChart3 className="h-8 w-8 text-blue-600" />
                        </div>
                        <div className="text-sm font-medium">Double Digits</div>
                        <div className="text-xs text-gray-500">10+ bottles</div>
                      </div>
                    )}
                    
                    {personalImpact.co2Saved >= 5 && (
                      <div className="text-center">
                        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                          <Leaf className="h-8 w-8 text-green-600" />
                        </div>
                        <div className="text-sm font-medium">Carbon Fighter</div>
                        <div className="text-xs text-gray-500">5kg+ CO₂ saved</div>
                      </div>
                    )}
                    
                    {personalImpact.totalBottles >= 50 && (
                      <div className="text-center">
                        <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                          <Award className="h-8 w-8 text-purple-600" />
                        </div>
                        <div className="text-sm font-medium">Recycling Hero</div>
                        <div className="text-xs text-gray-500">50+ bottles</div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="global">
            <div className="space-y-8">
              {/* Global Impact Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="h-5 w-5 mr-2 text-blue-600" />
                    Global Environmental Impact
                  </CardTitle>
                  <CardDescription>
                    Combined impact of all EcoBottle users
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6 text-center">
                    <div>
                      <div className="text-4xl font-bold text-blue-600 mb-2">
                        {globalStats.totalUsers.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-600">Active Users</div>
                    </div>
                    <div>
                      <div className="text-4xl font-bold text-green-600 mb-2">
                        {globalStats.totalBottles.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-600">Bottles Recycled</div>
                    </div>
                    <div>
                      <div className="text-4xl font-bold text-purple-600 mb-2">
                        {globalStats.totalCo2Saved.toLocaleString()} kg
                      </div>
                      <div className="text-sm text-gray-600">CO₂ Saved</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Top Recyclers */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Eco Warriors This Month</CardTitle>
                  <CardDescription>
                    Celebrating our most active recyclers
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {globalStats.topRecyclers.map((recycler, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            {index + 1}
                          </div>
                          <div>
                            <div className="font-medium">{recycler.name}</div>
                            <div className="text-sm text-gray-600">
                              {recycler.bottles.toLocaleString()} bottles recycled
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600">
                            {recycler.co2Saved} kg CO₂
                          </div>
                          <div className="text-sm text-gray-600">saved</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="learn">
            <div className="space-y-8">
              {recyclingFacts.map((section, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Lightbulb className="h-5 w-5 mr-2 text-yellow-600" />
                      {section.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                      {section.facts.map((fact, factIndex) => (
                        <div key={factIndex} className="p-4 bg-blue-50 rounded-lg">
                          <div className="text-sm text-blue-800">
                            {fact}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Call to Action */}
              <Card>
                <CardHeader>
                  <CardTitle>Make Every Bottle Count</CardTitle>
                  <CardDescription>
                    Your recycling efforts create real environmental impact
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Leaf className="h-16 w-16 text-green-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-4">
                      Keep up the amazing work!
                    </h3>
                    <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                      Every bottle you recycle contributes to a healthier planet. 
                      Together, we're making a significant difference in reducing waste 
                      and protecting our environment for future generations.
                    </p>
                    <Button 
                      onClick={() => router.push("/deposit")}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Recycle className="h-4 w-4 mr-2" />
                      Recycle More Bottles
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}